#!/usr/bin/perl -w

use warnings;
use strict;
use Indicator;


my $LTRscore    = $ARGV[0];
my $LTRtest     = $ARGV[1];
my $ROCresult   = $ARGV[2];
my $Threshold   = $ARGV[3];
my $AVROC   = $ARGV[4];
my $total_num  = $ARGV[5];

#read score and test files to generate the LTRlist
my (%resultList) = ();
open( LTRscore, $LTRscore ) || die "$!";
open( LTRtest,   $LTRtest )   || die "$!";
while (1) {
	my $score_line = <LTRscore>;
	my $test_line = <LTRtest>;
	last unless $score_line;

	chomp($score_line);
	my @tmp1 = split( /\t/, $score_line );    #print "@tmp1\n";
    next if ($tmp1[2] < $Threshold); # skip scores lower than threshold
        
	chomp($test_line);
	my @tmp2 = split( / /, $test_line );     #print "@tmp2\n";

	my ( $query, $result ) = ();
	$test_line =~ m/.+#(.+)\s.+\|(.+)\s.+/;    #print $1." ".$2."\n";
	$query  = $1;    #the first block matched in test_line
	$result = $2;    #the second block matched in test_line

	if ( $tmp2[0] == 1 ) {
		push @{ $resultList{$query} }, [ $result, $tmp1[2], 1 ];
	}
	else {
		push @{ $resultList{$query} }, [ $result, $tmp1[2], 0 ];
	}
}
close LTRscore;
close LTRtest;


open( ROC_writer, ">".$ROCresult ) || die "$!";
# record average value of ROC
my $ROC1_av = 0;
my $ROC10_av = 0;
my $ROC20_av = 0;
my $ROC30_av = 0;
my $ROC40_av = 0;
my $ROC50_av = 0;
#compute the ROC of each query
while (my ($k,$v)= each %resultList){
	#print $k. "\n";
	my $resultROC = $v;
	my ( $rocValue1, $rocValue10, $rocValue20, $rocValue30, $rocValue40, $rocValue50 ) = 0;
	if ($resultROC) {
		my @sortArray = ( sort { $b->[1] <=> $a->[1] } @$resultROC );  # decending order according to second column
		#foreach my $key (@sortArray){
		#	print $k."\t".${$key}[0]."\t".${$key}[1]."\t".${$key}[2]."\n";
		#}
		
		$rocValue1 = Indicator::ROC( \@sortArray, 1 );    #print $rocValue1."\t";
    $rocValue10 = Indicator::ROC( \@sortArray, 10 );    #print $rocValue1."\t";
    $rocValue20 = Indicator::ROC( \@sortArray, 20 );    #print $rocValue1."\t";
    $rocValue30 = Indicator::ROC( \@sortArray, 30 );    #print $rocValue1."\t";
    $rocValue40 = Indicator::ROC( \@sortArray, 40 );    #print $rocValue1."\t";
		$rocValue50 = Indicator::ROC( \@sortArray, 50 );    #print $rocValue50."\t";
	}
	$ROC1_av=$ROC1_av+$rocValue1;
  $ROC10_av=$ROC10_av+$rocValue10;
  $ROC20_av=$ROC20_av+$rocValue20;
  $ROC30_av=$ROC30_av+$rocValue30;
  $ROC40_av=$ROC40_av+$rocValue40;
	$ROC50_av=$ROC50_av+$rocValue50;
	print ROC_writer $k . "\t". $rocValue1."\t". $rocValue10."\t". $rocValue20."\t". $rocValue30."\t". $rocValue40. "\t" . $rocValue50 . "\n";	
}
close ROC_writer;
#my $total_num=scalar keys %resultList;
#my $total_num = 7329;
#print "hits/total num: " .(scalar keys %resultList). "/". $total_num. "\n";
print "roc1_av: " . ( $ROC1_av / $total_num ). "\troc10_av: " . ( $ROC10_av / $total_num ). "\troc20_av: " . ( $ROC20_av / $total_num ). "\troc30_av: " . ( $ROC30_av / $total_num ). "\troc40_av: " . ( $ROC40_av / $total_num ). "\troc50_av: " . ( $ROC50_av / $total_num ). "\n";

open( ROC_writer, ">".$AVROC ) || die "$!";
print ROC_writer"roc1_av: " . ( $ROC1_av / $total_num ). "\troc10_av: " . ( $ROC10_av / $total_num ). "\troc20_av: " . ( $ROC20_av / $total_num ). "\troc30_av: " . ( $ROC30_av / $total_num ). "\troc40_av: " . ( $ROC40_av / $total_num ). "\troc50_av: " . ( $ROC50_av / $total_num ). "\n";;	
close ROC_writer;