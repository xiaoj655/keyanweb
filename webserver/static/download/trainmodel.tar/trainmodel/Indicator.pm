#!/usr/bin/perl -w
package Indicator;

use strict;
use warnings;

=pod
my @test_roc =
  ( [ "a", 1 ], [ "b", 0 ], [ "c", 1 ], [ "d", 1 ], [ "e", 1 ], [ "f", 1 ] );
my @test_ndcg =
  ( [ "a", 5 ], [ "b", 3 ], [ "c", 4 ], [ "d", 1 ], [ "e", 2 ], [ "f", 1 ] );

my $rocValue = ROC( \@test_roc, 1 );
print $rocValue;
my $ndcgValue = NDCG( \@test_ndcg );
print $ndcgValue."\n";
=cut

sub ROC {
	my ( $qid_ResultList, $cutoff ) = @_;
	my ( $area, $height, $fp, $tp ) = ( 0, 0, 0, 0 );

	foreach my $result (@$qid_ResultList) {
		#print "@$result\n";
		my $y = @$result[2];
		#print @$result[0] . "\n";
		if ( $cutoff > $fp ) {
			if ( $y == 1 ) {
				$height++;
				$tp++;
				#print "ht:\t" . $height . "\t" . $tp . "\n";
			}
			if ( $y == 0 ) {
				$area += $height;
				$fp++;
				#print "area:\t" . $area . "\t" . $fp . "\n";
			}
		}
		else {
			#count remaining positives
			if ( $y == 1 ) {
				$tp++;
			}
		}
	}

	my $lroc = 0;
	if ( $fp != 0 && $tp != 0 ) {
		$lroc = $area / ( $fp * $tp );
	}
	if ( $fp == 0 && $tp != 0 ) {
		$lroc = 1;
	}
	if ( $fp != 0 && $tp == 0 ) {
		$lroc = 0;
	}
	return $lroc;

}

sub NDCG {
	my ($ResultList) = @_;
	my @optimalRanking = ();    #copy the @$ResultList not by the reference
	foreach my $result (@$ResultList) {
		#print "@$result\n";
		push @optimalRanking, [ $$result[0], $$result[1] ];
	}

	#caculate the Max DCG
	@optimalRanking = sort { $b->[1] <=> $a->[1] } @optimalRanking;	
	my ( $maxDCG, $position2 ) = ( 0, 0 );
	foreach my $result (@optimalRanking) {
		$position2++;
		my $gain = 2**@$result[1] - 1;               #Gain
		my $discountGain =
		  $gain * log(2) / log( 1 + $position2 );    #discounted gain
		push @$result, $gain;                        #push into the array
		$maxDCG += $discountGain;                    #cumulativeGain
		push @$result, $maxDCG;
		#print "@$result\n";
	}
	#print "\n";
	
	#caculate the DCG and NDCG
	my ( $DCG, $position1 ) = ( 0, 0 );
	foreach my $result (@$ResultList) {
		$position1++;
		my $gain = 2**@$result[1] - 1;    #Gain
		my $discountGain =
		  $gain * log(2) / log( 1 + $position1 );    #discounted gain
		push @$result, $gain;                        #push into the array
		$DCG += $discountGain;                       #cumulativeGain
		push @$result, $DCG;
		
		my $NDCG=$DCG/$optimalRanking[$position1-1][3];
		push @$result, $NDCG;
		#print "@$result\n";
	}
	return $$ResultList[-1][4];
}

1;