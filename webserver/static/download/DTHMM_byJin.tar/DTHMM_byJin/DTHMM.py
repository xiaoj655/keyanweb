# -----------------------------------------
# write by xiaopeng Jin (xpjin@bliulab.net)
# DTHMM 
# -----------------------------------------


from multiprocessing.dummy import Pool as ThreadPool
import sys 
import os
import time
import numpy as np
#import roc
from functools import partial
import os
from multiprocessing import Pool
import multiprocessing as mp

PROTEIN = "ACDEFGHIKLMNPQRSTVWY"
def make_kmer_list(k, alphabet):
	if k < 0:
		print("Error, k must be an inter and larger than 0.")

	kmers = []
	for i in range(1, k + 1):
		if len(kmers) == 0:
			kmers = list(alphabet)
		else:
			new_kmers = []
			for kmer in kmers:
				for c in alphabet:
					new_kmers.append(kmer + c)
			kmers = new_kmers

	return kmers



def dr_method(protein_name, inputfile, max_dis):
	if int(max_dis) > 0:
		aa_pairs = make_kmer_list(2, PROTEIN)
	aa_list = list(PROTEIN)
	vector_list = []
	with open(inputfile, 'r') as f:
		for line in f:
			vector = [protein_name]
			if line.strip().startswith('>'):
				continue
			else:
				line = list(line)
				len_line = len(line)
				for i in xrange(max_dis + 1):
					if i == 0:
						temp = [line.count(j) for j in aa_list]
						vector.extend(temp)
					else:
						new_line = []
						for index, elem in enumerate(line):
							if (index + i) < len_line:
								new_line.append(line[index] + line[index+i])
						temp = [new_line.count(j) for j in aa_pairs]
						vector.extend(temp)
			vector_list.append(vector)
	return vector_list

def extract_hmm_profile_top1(hhm_file, sequence, asterisks_replace=0.0):
	"""Extracts information from the hmm file and replaces asterisks."""
	profile_part = hhm_file.split('#')[-1]
	profile_part = profile_part.split('\n')
	whole_profile = [i.split() for i in profile_part]
	AA = whole_profile[2][1:]
	whole_profile = whole_profile[5:-2]
	gap_profile = np.zeros((len(sequence), 10))
	aa_profile = np.zeros((len(sequence), 20))
	top1_sequence = ''
	count_aa = 0
	count_gap = 0
	for line_values in whole_profile:
		if len(line_values) == 23:
			line_MAX_value = 0
			line_MAX_index = 0
			for j, t in enumerate(line_values[2:-1]):
				if t != '*':
					if float(t) > line_MAX_value:
						line_MAX_value = float(t)
						line_MAX_index = j
			top1_sequence += AA[line_MAX_index]
			count_aa += 1
		elif len(line_values) == 10:
			for j, t in enumerate(line_values):
				gap_profile[count_gap, j] = (
				2**(-float(t) / 1000.) if t != '*' else asterisks_replace)
			count_gap += 1
		elif not line_values:
			pass
		else:
			raise ValueError('Wrong length of line %s hhm file. Expected 0, 10 or 23'
							'got %d'%(line_values, len(line_values)))
	return top1_sequence


def save_DT_feature(path_ohhm, path_hmm_top1, path_hmm_DT, benchmark):
	ohmm_file = path_ohhm + benchmark

	with open(ohmm_file, 'r') as reader:
		ohmm_sequence = reader.read()

	query_file = 'xxxxxxxxxxxxxxxxxxxxx/scope-95-2.06-alone/' + benchmark[:-5] +'.fasta'
	query_data     = np.genfromtxt(query_file, dtype='string', comments='>')
	query_sequence = query_data
	query_sequence =  query_sequence.tostring()
	np.savetxt(path_hmm_top1+benchmark[:-5]+'.txt', ['>'+benchmark[:-5], extract_hmm_profile_top1(ohmm_sequence, query_sequence)], fmt='%s')
	np.savetxt(path_hmm_DT+benchmark[:-5]+'.txt',  dr_method(benchmark[:-5], path_hmm_top1+benchmark[:-5]+'.txt', 3), fmt='%s', delimiter='\t')

if __name__ == '__main__':

	path_ohhm     =  '**************************/206-ohhm/'
	path_hmm_top1 =  '**************************/206-hmm-feature-TOP1/'
	path_hmm_DT   =  '**************************/206-hmm-feature-DT/'
	benchmark_database =  os.listdir(path_ohhm)
	for_number = 0

	pool = mp.Pool(30)
	for benchmark in benchmark_database:
		pool.apply_async(save_DT_feature, (path_ohhm, path_hmm_top1, path_hmm_DT, benchmark))

	pool.close()
	pool.join()


